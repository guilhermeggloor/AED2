Trabalho de Algoritmo e Estrutura de Dados 2

Aluno: Guilherme Garcia Gloor
RGM: 45535

Para executar: make

para remover os arquivos: make clean

execução: ./main --> vai ser gerado o arquivo com o make

exemplos de valores de teste: 3, 5, 7, 8, 1, 2, -1, -2, 10, 25

